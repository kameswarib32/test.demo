package org.simplilearn;

import java.util.List;
import java.util.Scanner;

public class Test1 {

	public static void main(String[] args) {
		int ch;
		Scanner sc = new Scanner(System.in);
		EmpBO bo = new EmpBO();
		do {
			System.out.println("1.Insert Employee");
			System.out.println("2.Delete Employee");
			System.out.println("3.Display Employees");
			System.out.println("4.Getting an Employee");
			System.out.println("5.exit");
			System.out.println("Enter your choice");
			ch = sc.nextInt();
			switch (ch) {
			case 1:
				int eno;
				String name, address;
				System.out.println("Enter the employee details");
				eno = sc.nextInt();
				name = sc.next();
				address = sc.next();
				bo.addEmployee(new Emp(eno, name, address));
				break;
			case 2:
				System.out.println("Enter the eno to delete");
				eno = sc.nextInt();
				bo.deleteEmployee(eno);
				break;
			case 3:
				List<Emp> employees = bo.getEmployees();
				for (Emp e : employees)
					System.out.println(e.getEno() + "\t" + e.getName() + "\t" + e.getAddress());
				break;
			case 4:
				System.out.println("Enter the eno to delete");
				eno = sc.nextInt();
				Emp e=bo.getEmployee(eno);
				System.out.println(e.getEno()+"\t"+e.getName()+"\t"+e.getAddress());
				break;
			}
		} while (ch != 5);
	}

}
