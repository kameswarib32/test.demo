package org.simplilearn;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		ArrayList<Emp> employees=new ArrayList<>();
		readEmployees(employees);
		printEmployees(employees);
	}

	private static void printEmployees(ArrayList<Emp> employees) {
		System.out.println("The employee details are");
		for(Emp e:employees)
			System.out.println(e.getEno()+"\t"+e.getName()+"\t"+e.getAddress());
	}

	private static void readEmployees(ArrayList<Emp> employees) {
		int eno;
		String name,address;
		Scanner sc=new Scanner(System.in);
		for(int i=0;i<5;i++)
		{
			System.out.println("Enter the employee "+(i+1)+"details");
			eno=sc.nextInt();
			name=sc.next();
			address=sc.next();
			employees.add(new Emp(eno, name, address));
		}
	}

}
